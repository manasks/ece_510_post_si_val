regression Package
==================

:mod:`regression` Module
------------------------

.. automodule:: tap.regression.regression
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    tap.regression.tests

